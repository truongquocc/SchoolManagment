package com.vti.SchoolManagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolManagmentApplication.class, args);
	}

}
